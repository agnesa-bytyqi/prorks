<?php

require __DIR__ . '/../vendor/autoload.php';
require 'vars.php';
